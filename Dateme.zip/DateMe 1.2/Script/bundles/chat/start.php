<?php


Autoloader::directories(array(
    Bundle::path('chat').'models',
   
));