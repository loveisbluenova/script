<?php

class Chat extends Eloquent {



}