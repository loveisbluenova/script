<?php

class Contact extends Eloquent {



}