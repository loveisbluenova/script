<?php


class Credit extends Eloquent{
}