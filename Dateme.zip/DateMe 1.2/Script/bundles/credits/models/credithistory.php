<?php


class Credithistory extends Eloquent{
	
	public static $table = 'credithistory';
}