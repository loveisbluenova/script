<?php


class Superpower extends Eloquent{
	
	public static $table = 'superpowers';
}