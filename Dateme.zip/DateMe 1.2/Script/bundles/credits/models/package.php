<?php


class Package extends Eloquent{
}