<?php


class Czar extends Eloquent{





}