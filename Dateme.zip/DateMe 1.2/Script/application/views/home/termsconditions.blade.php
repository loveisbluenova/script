@layout('home.page')



@section('content')
<div class="border-div" style="padding:50px;">
<div style="text-align:center">
{{ t('termsconditionscontent') }}


@endsection